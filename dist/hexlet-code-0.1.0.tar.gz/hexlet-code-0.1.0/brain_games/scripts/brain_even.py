#!/usr/bin/env python3

from brain_games.games.even import even_number


def main():
    print(even_number())


if __name__ == '__main__':
    main()
