#!/usr/bin/env python3

from brain_games.games.calc import calculate_answer


def main():
    print(calculate_answer())


if __name__ == '__main__':
    main()
